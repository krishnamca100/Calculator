


function calC(c) {

      form.panel.value = form.panel.value + c;


}


function CE() {
    form.panel.value = "";
}

alert("hi");